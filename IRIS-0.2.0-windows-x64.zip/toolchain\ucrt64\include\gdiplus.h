#include "gdiplus/gdiplus.h"
